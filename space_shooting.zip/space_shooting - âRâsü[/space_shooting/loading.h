#ifndef __LOADING_H__
#define __LOADING_H__

#include<DxLib.h>

enum youso
{
	field,enemy1,enemy2,enemy3,player,boss
};

extern int G_IMGhandle[10][13];
extern int gif[4][12];
extern int BOSS;
extern int TITLE;
extern int BULLET[4];

BOOL IMGhandle();
BOOL InitBulletImage(int);

#endif