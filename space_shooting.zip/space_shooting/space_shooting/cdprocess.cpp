#include"cdprocess.h"

#define SCROLL_STAPOS 500

float scrolly = 0;

void move(){
	int key = GetJoypadInputState(DX_INPUT_KEY_PAD1);

	int aa = timer;
	float hy = HERO.y - 1700;
	aa += 1;
	if (timer < aa)
	{
		scrolly += 1;
	}

	if (key & PAD_INPUT_UP && CheckEnd(1) == TRUE){
		HERO.y -= HERO.movement;

		if (HERO.SF == TRUE){

		}
	}
	if (key & PAD_INPUT_DOWN && CheckEnd(2) == TRUE){
		HERO.y += HERO.movement;

		if (HERO.SF == TRUE){

		}
	}
	if (key & PAD_INPUT_LEFT && CheckEnd(3) == TRUE){
		HERO.x -= HERO.movement;
	}
	if (key & PAD_INPUT_RIGHT && CheckEnd(4) == TRUE){
		HERO.x += HERO.movement;
	}

}

BOOL CheckEnd(int i){

	

	return TRUE;
	
}
void CheckScroll(BOOL flag){
	
	
	
	
}
void DrawBullet(int flag){
	int largefont = CreateFontToHandle("���C���I", 42, -1, DX_FONTTYPE_NORMAL);

	if (flag == E){

	}else if (flag == P){
		for (int i = 0; HERO.BULLET[i].living == TRUE; i++){
			switch (HERO.BULLET[i].type)
			{
			case red:
				DrawGraph(HERO.BULLET[i].x, HERO.BULLET[i].y - 1950, HERO.BULLET[i].BULLET_IMAGE, TRUE);
				break;
			case blue:
				DrawGraph(HERO.BULLET[i].x, HERO.BULLET[i].y - 1950, HERO.BULLET[i].BULLET_IMAGE, TRUE);
				break;
			case green:
				DrawGraph(HERO.BULLET[i].x, HERO.BULLET[i].y - 1950, HERO.BULLET[i].BULLET_IMAGE, TRUE);
				break;
			case beam:
				DrawExtendGraph(HERO.BULLET[i].x,HERO.BULLET[i].y - 1950,HERO.BULLET[i].x + IMGSIZE,HERO.BULLET[i].y - 1950 + IMGSIZE,HERO.BULLET[i].BULLET_IMAGE,TRUE);
				break;
			}
			if (HERO.BULLET[i].y + IMGSIZE <= (HERO.y + 110 - gamemainsize_y)){
				HERO.BULLET[i].living = FALSE;
			}
			if(HERO.BULLET[i].living == TRUE){
				HERO.BULLET[i].y -= HERO.BULLET[i].movement;
			}
		}
	}
	
}