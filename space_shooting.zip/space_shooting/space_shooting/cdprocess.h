#ifndef __CDPROCESS_H__
#define __CDPROCESS_H__

#include"main.h"
#include"gamemain.h"
#include"cdflame.h"

#endif