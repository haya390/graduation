#ifndef __GAMEMAIN_H__
#define __GAMEMAIN_H__

#include<DxLib.h>

void gamemain();

#endif