#ifndef __LOADING_H__
#define __LOADING_H__

#include<DxLib.h>
#include<stdio.h>

BOOL IMGhandle();

extern int G_IMGhandle[30];

#endif