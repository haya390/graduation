#include"main.h"
#include<DxLib.h>

int WINAPI WinMain(HINSTANCE h1, HINSTANCE hp, LPSTR lpc, int nC){
	ChangeWindowMode(TRUE);
	if (DxLib_Init() == -1)return -1;
	WaitKey();
	DxLib_End();
	return 0;
}